$(document).ready(function(){
	//dropdown menu
	$('.ui.dropdown').dropdown();
	
	//slide banner
	$('.banner').unslider({
		arrows: true,
		fluid: true,
		dots: true
	});
	
	// loading next page and append to prev page
	var a = $(".next-page-link a");
	var prevPageUrl = '';
	var nextPageUrl = '';

	if(a.length > 0){
		nextPageUrl = a.attr("href");
	}
	
	$(window).bind("scroll", function(){
		if($(document).scrollTop() +  $(window).height() > $(document).height() - 20){
			
			if(nextPageUrl == ''){
				return;
			}

			if(prevPageUrl == nextPageUrl){
				return;
			}

			$.ajax({
				url: nextPageUrl,
				type: 'POST',
				dataType: 'html',
				beforeSend:function(){
					$(".loading-status").css("display", "block");
				},
				complete: function(){
					$(".loading-status").css("display", "none");
				},
				success: function(data){
					var $res = $(data).find('.projects').html();
					$(".projects").append($res);
					
					prevPageUrl = nextPageUrl;
					
					if($(data).find('.next-page-link a').length > 0){
						nextPageUrl = $(data).find('.next-page-link a').attr("href");
					}else{
						nextPageUrl = '';
						$(".end-message").css("display", "block");
					}
				}
			});
		}
	});

	//scroll to top
	$.scrollUp({
		scrollName: 'scrollUp',
		topDistance: '100',
		topSpeed: 300,
		animation: 'fade',
		animationInSpeed: 200,
		animationOutSpeed: 200,
		scrollText: '',
		activeOverlay: false
	});

})