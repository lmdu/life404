<?php $this->need("header.php"); ?>

<div class="breadcrumb-box">
	<div class="breadcrumb-inner">
		<div class="ui middle aligned two column grid">
			<div class="column">
				<div class="ui large breadcrumb">
					<i class="icon location"></i>当前位置: 
					<a href="<?php $this->options->siteUrl(); ?>">首页</a>
					<i class="right arrow icon divider"></i>
					<?php $this->title(); ?>
				</div>
			</div>
			<div class="right aligned column">
				<?php echo $this->options->breadcrumbAD468; ?>
			</div>
		</div>
	</div>
</div>

<div class="page-container clearfix">
	<?php $this->need('sidebar.php'); ?>
	<div class="content-box">
		<div class="article-box">
			<h2 class="header"><?php $this->title() ?></h2>
			<div class="article-content">
				<?php $this->content(); ?>
			</div>
			<div class="article-tag">

			</div>
			<div class="article-link">

			</div>
		</div>
	</div>
</div>
<?php $this->need('footer.php'); ?>