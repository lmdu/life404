<?php
function themeConfig($form){
	
	// index page slide image
	$slideImage = new Typecho_Widget_Helper_Form_Element_Textarea('slideImage', NULL,  NULL, _t('首页幻灯片设置'), _t('填写图片URL地址, 并编辑成Unslider可用的格式'));
	$form->addInput($slideImage);
	
	// blogroll links
	$blogroll = new Typecho_Widget_Helper_Form_Element_Textarea('blogroll', NULL,  NULL, _t('友情链接'), _t('友情链接URL'));
	$form->addInput($blogroll);

	//sidebar 250 x 250 advertise
	$sidebarAD250 = new Typecho_Widget_Helper_Form_Element_Textarea('sidebarAD250', NULL,  NULL, _t('侧边栏广告'), _t('侧边栏广告, 广告尺寸为250 x 250'));
	$form->addInput($sidebarAD250);

	//breadcrumb bar 468 x 60 advertise
	$breadcrumbAD468 = new Typecho_Widget_Helper_Form_Element_Textarea('breadcrumbAD468', NULL,  NULL, _t('面包屑广告'), _t('面包屑广告栏广告, 广告尺寸为468 x 60'));
	$form->addInput($breadcrumbAD468);

}