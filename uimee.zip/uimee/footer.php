<div class="footer">
	<div class="ui grid footer-box">
		<div class="three wide column">
			<div class="slogo"></div>
		</div>
		<div class="six wide column">
			<p><?php $this->options->description(); ?></p>
			<p>版权归 &copy;2014 UI迷 所有. 本站所有开源项目均收集于互联网</p>
			<p>本站由 <a href="http://typecho.org" target="_blank">Typecho</a> 强力驱动. 本站Typecho主题基于 <a href="http://www.semantic-ui.com" target="_blank">Semantic UI</a> 前端框架开发. 使用  <i class="linux icon"></i><a href="http://my.hengtian.org/aff.php?aff=2089" target="_blank">衡天主机</a> 和 <i class="cloud icon"></i><a href="http://www.qiniu.com/" target="_blank">七牛云储</a></p>
		</div>
		<div class="four wide column">
		</div>
		<div class="three wide right aligned column supports">
			<i class="rss icon large link"></i>
			<i class="html5 icon large link"></i>
			<i class="css3 icon large link"></i>
			<i class="github icon large link"></i>
			<i class="weibo icon large link"></i>
		</div>
	</div>	
</div>
</body>
</html>