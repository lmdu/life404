<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
<title>
<?php 
$this->archiveTitle(array('category' => _t('分类 %s 下的文章'), 'search' => _t('包含关键字 %s 的文章'), 'tag' => _t('标签 %s 下的文章'), 'author' => _t('%s 发布的文章')), '', ' - ');
$this->options->title();
?>
</title>

<link rel="stylesheet" type="text/css" class="ui" href="<?php $this->options->themeUrl('semantic/css/semantic.min.css'); ?>">
<link rel="stylesheet" type="text/css" href="<?php $this->options->themeUrl('style.css'); ?>">
<?php $this->header('generator=&template=&pingback=&xmlrpc=&wlw=&commentReply='); ?>
<script type="text/javascript" src="http://upcdn.b0.upaiyun.com/libs/jquery/jquery-1.9.1.min.js"></script>
<script type="text/javascript" src="<?php $this->options->themeUrl('semantic/javascript/semantic.min.js'); ?>"></script>
<script type="text/javascript" src="<?php $this->options->themeUrl('js/unslider.min.js'); ?>"></script>
<script type="text/javascript" src="<?php $this->options->themeUrl('js/jquery.scrollUp.min.js'); ?>"></script>
<script type="text/javascript" src="<?php $this->options->themeUrl('js/custom.js'); ?>"></script>
</head>
<body>
<nav class="ui fixed transparent inverted main menu">
	<div class="container">
		<a href="<?php $this->options->siteUrl(); ?>" class="logo item"></a>
		
		<a class="item <?php if($this->is('index')): ?> active <?php endif; ?>" href="<?php $this->options->siteUrl(); ?>"><?php _e('首页'); ?></a>

		<?php $this->widget('Widget_Metas_Category_List')->to($cats); ?>
		<?php while($cats->next()): ?>
		<a class="item <?php if($this->is('category', $cats->slug)): ?> active <?php endif; ?>" href="<?php $cats->permalink(); ?>" title="<?php $cats->name(); ?>"><?php $cats->name(); ?></a>
 		<?php endwhile; ?>

		<div class="right menu">
			<?php $this->widget('Widget_Contents_Page_List')->to($pages); ?>
			<?php while($pages->next()): ?>
			<a class="item <?php if($this->is('page', $pages->slug)): ?> active <?php endif; ?>" href="<?php $pages->permalink(); ?>" title="<?php $pages->title(); ?>"><?php $pages->title(); ?></a>
 			<?php endwhile; ?>
		</div>
	</div>
</nav>
