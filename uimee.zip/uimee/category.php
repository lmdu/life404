<?php $this->need("header.php"); ?>

<div class="breadcrumb-box">
	<div class="breadcrumb-inner">
		<div class="ui middle aligned two column grid">
			<div class="column">
				<div class="ui large breadcrumb">
					<i class="icon location"></i>当前位置: 
					<a href="<?php $this->options->siteUrl(); ?>">首页</a>
					<i class="right arrow icon divider"></i>
					<?php $this->category(); ?>
				</div>
			</div>
			<div class="right aligned column">
				<?php echo $this->options->breadcrumbAD468; ?>
			</div>
		</div>
	</div>
</div>

<div class="page-container clearfix">
	<?php $this->need('sidebar.php'); ?>
	<div class="content-box">
		<div class="ui three column stackable grid projects">
			<?php while($this->next()): ?>
			<div class="column">
				<div class="ui stacked segment">
					<div class="thumbnail" style="background:url(<?php $this->fields->thumbnail(); ?>)"></div>
					<h2><a href="<?php $this->permalink() ?>"><?php $this->title(); ?></a></h2>
					<div class="project-categroy"><?php $this->category(','); ?></div>
					<div class="description"><?php $this->content(); ?></div>
					<div class="project-links">
						<a href="<?php $this->fields->homepage(); ?>" class="ui tiny blue button"><i class="home icon"></i>官方网站</a>
						<a href="<?php $this->fields->document(); ?>" class="ui tiny orange button"><i class="book icon"></i>使用说明</a>
						<a href="<?php $this->fields->download(); ?>" class="ui tiny green button"><i class="download icon"></i>下载</a>
					</div>
				</div>
			</div>
		<?php endwhile; ?>
		</div>
	</div>

	<div class="loading-status">
		<div class="ui large active inline loader"></div>
		<!--<i class="huge loading icon"></i>-->
	</div>

	<div class="end-message">
		<div class="ui red icon message">
			<i class="leaf icon"></i>
			<div class="content">
				<div class="header">更多项目还在不断添加中...</div>
				<p>如果您知道其他一些优秀的开源项目, 愿意和我们一起分享给大家</p>
				<p>可以通过 <span class="ui green label"><?php $this->author->mail(); ?></span> 发送给我们</p>
				<p>感谢您的合作与支持!</p>
			</div>
		</div>
	</div>

	<div class="next-page-link" style="display:none;"><?php $this->pageLink('', 'next'); ?></div>
</div>
<?php $this->need('footer.php'); ?>