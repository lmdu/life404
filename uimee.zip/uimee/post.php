<?php $this->need("header.php"); ?>

<div class="breadcrumb-box">
	<div class="breadcrumb-inner">
		<div class="ui middle aligned two column grid">
			<div class="column">
				<div class="ui large breadcrumb">
					<i class="icon location"></i>当前位置: 
					<a href="<?php $this->options->siteUrl(); ?>">首页</a>
					<i class="right arrow icon divider"></i>
					<?php $this->category(); ?>
					<i class="right arrow icon divider"></i>
					<?php $this->title(); ?>
				</div>
			</div>
			<div class="right aligned column">
				<?php echo $this->options->breadcrumbAD468; ?>
			</div>
		</div>
	</div>
</div>

<div class="page-container clearfix">
	<?php $this->need('sidebar.php'); ?>
	<div class="content-box">
		<div class="article-box">
			<div class="article-header">
				<h2><?php $this->title(); ?></h2>
				<div class="article-header-links">
					<?php if(isset($this->fields->homepage)): ?>
					<a href="<?php $this->fields->homepage(); ?>" class="ui blue small button"><i class="globe icon"></i><?php _e("官方网站") ?></a>
					<?php endif; ?>

					<?php if(isset($this->fields->download)): ?>
					<a href="<?php $this->fields->download(); ?>" class="ui green small button"><i class="download icon"></i><?php _e("下载地址") ?></a>
					<?php endif; ?>

					<?php if(isset($this->fields->english) && isset($this->fields->chinese)): ?>
					<div class="ui buttons">
						<a class="ui orange small button" href="<?php $this->fields->english(); ?>">中文文档</a>
						<div class="or"></div>
						<a class="ui purple small button" href="<?php $this->fields->chinese(); ?>">英文文档</a>
					</div>
					<?php elseif(isset($this->fields->english)): ?>
					<a class="ui purple small button" href="<?php $this->fields->chinese(); ?>">英文文档</a>
					<?php elseif(isset($this->fields->chinese)): ?>
					<a class="ui orange small button" href="<?php $this->fields->english(); ?>">中文文档</a>
					<?php endif; ?>

					<?php if(isset($this->fields->demo)): ?>
					<a class="ui red small button" href="<?php $this->fields->demo(); ?>">实例演示</a>
					<?php endif; ?>
				</div>
			</div>
			<div class="article-meta">
				<span><i class="ui icon time"></i> 发布于: <?php $this->date('F j, Y'); ?></span> <span><i class="ui icon list"></i> 分类: <?php $this->category(); ?></span>
			</div>
			<div class="article-content">
				<?php $this->content(); ?>
			</div>
			<!--
			<div class="article-tag">
				<?php $this->tags(' ', true, 'none'); ?>
			</div>
		-->
			<div class="article-link">
				<?php if(isset($this->fields->homepage)): ?>
				<a href="<?php $this->fields->homepage(); ?>" class="ui blue button"><i class="globe icon"></i><?php _e("官方网站") ?></a>
				<?php endif; ?>

				<?php if(isset($this->fields->download)): ?>
				<a href="<?php $this->fields->download(); ?>" class="ui green button"><i class="download icon"></i><?php _e("下载地址") ?></a>
				<?php endif; ?>

				<?php if(isset($this->fields->english) && isset($this->fields->chinese)): ?>
				<div class="ui buttons">
					<a class="ui orange button" href="<?php $this->fields->english(); ?>">中文文档</a>
					<div class="or"></div>
					<a class="ui purple button" href="<?php $this->fields->chinese(); ?>">英文文档</a>
				</div>
				<?php elseif(isset($this->fields->english)): ?>
				<a class="ui purple button" href="<?php $this->fields->chinese(); ?>">英文文档</a>
				<?php elseif(isset($this->fields->chinese)): ?>
				<a class="ui orange button" href="<?php $this->fields->english(); ?>">中文文档</a>
				<?php endif; ?>

				<?php if(isset($this->fields->demo)): ?>
				<a class="ui red button" href="<?php $this->fields->demo(); ?>">实例演示</a>
				<?php endif; ?>

			</div>
		</div>
	</div>
</div>
<?php $this->need('footer.php'); ?>
