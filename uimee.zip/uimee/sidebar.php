<div class="side-box">
	<!-- category page -->
	<?php if($this->is('category')): ?>
	<div class="ui large fluid pointing vertical menu">
		<?php $this->widget('Widget_Metas_Category_List')->to($cats); ?>
		<?php while($cats->next()): ?>
		<?php if($this->is('category', $cats->slug)): ?>
		<a class="item active orange" href="<?php $cats->permalink(); ?>" title="<?php $cats->name(); ?>">
			<div class="ui orange circular label"><?php $cats->count(); ?></div>
			<?php $cats->name(); ?>
		</a>
		<?php else: ?>
		<a class="item" href="<?php $cats->permalink(); ?>" title="<?php $cats->name(); ?>">
			<div class="ui circular label"><?php $cats->count(); ?></div>
			<?php $cats->name(); ?>
		</a>
		<?php endif; ?> 
		<?php endwhile; ?>
	</div>
	<?php endif; ?>

	<?php if($this->is('page')): ?>
	<?php $this->widget('Widget_Contents_Page_List')->to($pages); ?>
	<div class="ui large fluid pointing vertical menu">
		<?php while($pages->next()): ?>
		<a class="item <?php if($this->is('page', $pages->slug)): ?> active <?php endif; ?>" href="<?php $pages->permalink(); ?>" title="<?php $pages->title(); ?>"><?php $pages->title(); ?></a>
		<?php endwhile; ?>
	</div>
	<?php endif; ?>

	<div class="sidebar-ad">
		<?php echo $this->options->sidebarAD250; ?>
	</div>
</div>