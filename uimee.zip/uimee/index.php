<?php
/**
 * This is a simple theme.
 *
 * @package Uimee Theme
 * @author Ming
 * @version 0.1
 * @link http://www.uimee.com
 */

$this->need('header.php');
?>

<div class="banner">
	<?php echo $this->options->slideImage; ?>
</div>

<div class="breadcrumb-box">
	<div class="breadcrumb-inner">
		<div class="ui middle aligned two column grid">
			<div class="column">
				<div class="ui large breadcrumb">
					<i class="icon location"></i>当前位置: 
					<a href="<?php $this->options->siteUrl(); ?>">首页</a>
					<i class="right arrow icon divider"></i>
					<a>最新项目</a>
				</div>
			</div>
			<div class="right aligned column">
				<?php echo $this->options->breadcrumbAD468; ?>
			</div>
		</div>
	</div>
</div>

<div class="main-content">
	<div class="project-header">
		<h1 class="ui header">
			<div class="content">
				前端框架及相关开源项目收录数据统计
				<div class="sub header">
					<?php Typecho_Widget::widget('Widget_Stat')->to($stat); ?>
					共收录 <?php echo $stat->publishedPostsNum; ?> 个前端和相关开源项目, 共创建 <?php echo $stat->categoriesNum; ?> 个分类
				</div>
			</div>
		</h1>
	</div>

	<div class="ui five stackable column grid stat-boxes">
		<?php 
			$colors = array("black", "green","red","blue","orange","purple","teal");
			shuffle($colors); 
		?>
		<?php $this->widget('Widget_Metas_Category_List')->to($cats); ?>
		<?php while($cats->next()): ?>
		<div class="column">
			<div class="ui stacked segment">
				<div class="ui large top left attached label <?php echo array_pop($colors); ?>"><?php echo $cats->name; ?></div>
				<div class="ui statistic">
					<div class="number"><?php echo $cats->count; ?></div>
					<div class="description">个项目</div>
				</div>
			</div>
		</div>
		<?php endwhile; ?>
	</div>

	<div class="project-header">
		<h1 class="ui header">
			<div class="content">
				已收录的前端框架及相关开源项目
				<div class="sub header">
					这些项目包括前端框架、前端框架的扩展组件和强化包
				</div>
			</div>
		</h1>
	</div>

	<div class="ui four column stackable grid projects">
		<?php while($this->next()): ?>
		<div class="column">
			<div class="ui stacked segment">
				<div class="thumbnail" style="background:url(<?php $this->fields->thumbnail(); ?>)"></div>
				<h2><a href="<?php $this->permalink(); ?>"><?php $this->title(); ?></a></h2>
				<div class="project-categroy"><?php $this->category(','); ?></div>
				<div class="description"><?php $this->content(); ?></div>
				<div class="project-links">
					<a href="<?php $this->permalink(); ?>" class="ui tiny button">了解更多</a>
				</div>
			</div>
		</div>
		<?php endwhile; ?>
	</div>

	<div class="loading-status">
		<div class="ui large active inline loader"></div>
		<!--<i class="huge loading icon"></i>-->
	</div>

	<div class="end-message">
		<div class="ui red icon message">
			<i class="leaf icon"></i>
			<div class="content">
				<div class="header">更多项目还在不断添加中...</div>
				<p>如果您知道其他一些优秀的开源项目, 愿意和我们一起分享给大家</p>
				<p>可以通过 <span class="ui green label"><?php $this->author->mail(); ?></span> 发送给我们</p>
				<p>感谢您的合作与支持!</p>
			</div>
		</div>
	</div>

	<div class="next-page-link" style="display:none;"><?php $this->pageLink('', 'next'); ?></div>

</div>

<?php $this->need('footer.php'); ?>
